# Changelog
All notable changes to this project will be documented in this file.

## [1.1] - 2019-05-12
### Massive restructuring of package structure and Class names
```
/App.java
/apache/HDFS.java -> /apache/hadoop/HDFS.java
/apache/SparkExecutor.java -> /apache/spark/SparkExecutor.java
/dev/DummyData.java -> /development/DummyData.java
/dev/Sandbox.java -> /development/Sandbox.java

/qep/URIs.java -> /database/rdf/URIs.java
/qep/ParserBlocksCreator.java -> /parser/BlocksCreator.java
/qep/QEPUtils.java
/qep/RdfCreator.java -> /database/rdf/RdfCreator.java
/qep/ranker/Plan.java -> /ranker/Plan.java
/qep/ranker/Rank.java -> /ranker/Rank.java
/qep/ranker/RANKPROPS.java -> /ranker/RANKPROPS.java
/qep/guidelines/Guidelines.java -> /guidelines/Guidelines.java
/qep/guidelines/GuidelineObj.java -> /guidelines/GuidelineObj.java
/qep/guidelines/GuidelineSQL.java -> /guidelines/GuidelineSQL.java
/qep/sql/TableJoinGen.java -> /query/sql/TableJoinGen.java
/qep/sql/QueryGenerator.java -> /query/sql/QueryGenerator.java
/qep/SPARQL/SPARQLQuery.java -> /query/sparql/SPARQLQuery.java
/qep/SPARQL/QueryObject.java -> /query/sparql/QueryObject.java
/qep/SPARQL/QueryCreator.java -> /query/sparql/QueryCreator.java
/qep/SPARQL/QueryGraph.java -> /query/sparql/QueryGraph.java
/qep/SPARQL/SignatureSimilarity.java -> /query/sparql/SignatureSimilarity.java
/qep/RDF/QEPTemplate.java -> /database/rdf/QEPTemplate.java
/qep/RDF/PROPERTIES.java -> /database/rdf/PROPERTIES.java
/qep/RDF/PredicateNode.java -> /database/rdf/PredicateNode.java
/qep/RDF/QEPModel.java -> /database/rdf/QEPModel.java
/qep/RDF/Predicate.java -> /database/rdf/Predicate.java
/qep/parser/Property.java -> /parser/Property.java
/qep/parser/Parser.java -> /parser/Parser.java
/qep/parser/Block.java -> /parser/Block.java

/utils/UserSessionLog.java -> /user/SessionLog.java
/utils/User.java -> /user/User.java
/utils/Init.java -> /utils/Initializer.java
/utils/Utils.java 
/utils/CustomPartitioner.java -> /apache/spark/CustomPartitioner.java
/utils/Encryptor.java
/utils/Experiments.java -> /development/Experiments.java
/utils/Config.java -> /user/Config.java
/utils/Convert.java -> /utils/Converter.java

/database/DBRDF.java -> /database/rdf/RDF.java
/database/DBTPCDS.java -> database/tpcds/TPCDS.java
/database/DB.java -> /database/db2/DB.java

/db2/DB2Executor.java -> /database/db2/DB2Executor.java
/db2/Sql.java -> /query/sql/Sql.java
/db2/DB2.java -> /database/db2/DB2.java
```

## [1.0] - 2019-05-12
* Fully implemented version of Galo, with simple partitioning (divided all by 2 randomly)

[1.0]: https://github.com/amihaylo/distGalo/releases/tag/v1.0
[1.1]: https://github.com/amihaylo/distGalo/compare/v1.0...v1.1
