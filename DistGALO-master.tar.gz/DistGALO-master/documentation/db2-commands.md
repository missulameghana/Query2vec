# Database CRUD

| Command  | Detail   |
|----------|----------|
| `db2 list db directory` | List all databases |
| `db2 connect to <DB-NAME>` | Connects to the specified database |
| `db2 connect to <DB-NAME> user <USER-NAME> using <USER_PSW>` | Connects to the specified database |
| `db2 list tables` | List all the tables for the currently connected database |
| `db2 describe table <TABLE-NAME>` | Display the schema for the table |
| `db2 "ALTER TABLE <TABLE_NAME> DROP COLUMN <COLUMN_NAME>"` | Drop a Column from a table |
| `db2 disconnect <DB-NAME>` | Connects to the specified database |
| `db2 drop database <db-name>` | Drops the specified database |
| `command` | Detail |


# Generating explain actuals
| Step# | Command | Detail |
| ----- | ------- | ------ |
| 1 | `command` | explanation |
| 2 | `db2 connect to <DB>` | connect to Database |
| 3 | `db2 set current schema current user` | Set default schema to current user |
| 4 | `db2 delete from ACTIVITYSTMT_EM1` + `db2 delete from ACTIVITYVALS_EM1` + `db2 delete from ACTIVITY_EM1` + `db2 delete from CONTROL_EM1` | clean the tables |
| 5 | `db2 set event monitor em1 state 1` | Enable the event monitor |
| 6 | `db2batch -d <DB> -a <username>/<pass> -f <path-to-prepared-sql> -r <filename>.out -i complete -o p 5 e yes r 0 2>&1` | explanation |
| 7 | `db2 set event monitor em1 state 0` | Disable the event monitor |
| 8 | `python ./src/scripts/actualsToExplain.py --database <DB> --user <username> --pswd <password> --input <path-to-prepared-sql>` | Grab the activity and store it into the explain tables |
| 9 | `db2exfmt -d <DB> -1 -o <filename>.explain -u <username> <password>` | Run exfmt to collect the actuals |




# Table Logs
| Command  | Detail   |
|----------|----------|
| `db2 "CREATE SEQUENCE logs_id_sequence start with 1 increment by 1"` | |
| `db2 "CREATE BUFFERPOOL BPOOL  SIZE 2000 PAGESIZE 32K"` | |
| `db2 "CREATE TABLESPACE OPTIDATASPACE PAGESIZE 32K BUFFERPOOL BPOOL"` | |
| `db2 "CREATE TABLE LOGS ( LOG_ID bigint NOT NULL PRIMARY KEY, JSON_PATTERN VARCHAR(10000), SPARQL_GENERATED VARCHAR(10000), POPS_RETRIEVED VARCHAR(10000), EXPLAIN_FILE CLOB(2M), RDF_FILE CLOB(2M), FILE_NAME VARCHAR(300)) IN OPTIDATASPACE"` | |

# Table Kb
| Command  | Detail   |
|----------|----------|
| `db2 "CREATE SEQUENCE kb_id_sequence start with 1 increment by 1"` | |
| `db2 "CREATE TABLE KB ( KB_ID bigint NOT NULL PRIMARY KEY, TAG VARCHAR(100) NOT NULL, RECOMMENDATION VARCHAR(10000) NOT NULL, QUERY VARCHAR(10000) NOT NULL)"` | |

# Table Problem_Report
| Command  | Detail   |
|----------|----------|
| `db2 "CREATE SEQUENCE pr_id_sequence start with 1 increment by 1"` | |
| `db2 "CREATE TABLE PROBLEM_REPORT ( PR_ID bigint NOT NULL PRIMARY KEY, USER VARCHAR(100), EMAIL VARCHAR(100), DESCRIPTION VARCHAR(10000) NOT NULL, LOG_ID_FK bigint, FOREIGN KEY(LOG_ID_FK) REFERENCES LOGS(LOG_ID) ON DELETE CASCADE)"` | |

# Table Kb_Log_Line
| Command  | Detail   |
|----------|----------|
| `db2 "CREATE TABLE KB_LOG_LINE ( KB_ID bigint NOT NULL, LOG_ID bigint NOT NULL, FOREIGN KEY(KB_ID) REFERENCES KB(KB_ID) ON DELETE CASCADE, FOREIGN KEY(LOG_ID) REFERENCES LOGS(LOG_ID) ON DELETE CASCADE)"` | |

# Table Kb_Plans
| Command  | Detail   |
|----------|----------|
| `db2 "CREATE SEQUENCE kb_plans_id_sequence start with 1 increment by 1"` | |
| `db2 "CREATE BUFFERPOOL BPOOL  SIZE 2000 PAGESIZE 32K"` | |
| `db2 "CREATE TABLESPACE OPTIDATASPACE PAGESIZE 32K BUFFERPOOL BPOOL"` | |
| `db2 "CREATE TABLE KB_PLANS ( KB_PLANS_ID bigint NOT NULL PRIMARY KEY, QUERY_GENERATED VARCHAR(10000), SPARQL_GENERATED VARCHAR(10000), GUIDELINE VARCHAR(10000), RDF_FILE CLOB(2M)) IN OPTIDATASPACE"` | |

# Other
| Command  | Detail   |
|----------|----------|
| `db2 alter bufferpool BP_16K size 5000` | Modify the bufferpool |
| `db2set -im DB2_SYSTEM_RAM="200 MB` | Modify the RAM |
| `db2 "explain plan for <SQL QUERY>"` then `db2exfmt -d tpcdsx -1 -o temp.exfmt` | Generate exfmt for a given query |
