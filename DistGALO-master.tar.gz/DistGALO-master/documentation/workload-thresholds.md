# Attach to each query
CALL SYSPROC.WLM_SET_CLIENT_INFO(NULL, NULL,'TEST_APP_99_1_1', NULL, NULL);

# Create the Workload, and threshold
db2 "CREATE WORKLOAD TEST_WL_99_1_1 CURRENT CLIENT_APPLNAME('TEST_APP_99_1_1')";
db2 "CREATE THRESHOLD TEST_TH_99_1_1 FOR WORKLOAD TEST_WL_99_1_1 ACTIVITIES ENFORCEMENT DATABASE ENABLE WHEN ACTIVITYTOTALTIME > 10 SECONDS STOP EXECUTION";

# Verfiy they all were added
db2 "select workloadname from syscat.workloads";
db2 "select thresholdname from syscat.thresholds";

# Drop afterwards since they are not needed (Order matters)
db2 "DROP THRESHOLD TEST_TH_99_1_1";
db2 "ALTER WORKLOAD TEST_WL_99_1_1 DISABLE";
db2 "DROP WORKLOAD TEST_WL_99_1_1";

--------------------
# Drop all user created Workloads and Thresholds
db2 "SELECT thresholdname FROM syscat.thresholds WHERE thresholdname LIKE '%TH%'" | grep _TH | xargs -I % bash -c 'db2 connect to tpcds; db2 "DROP THRESHOLD %"';
db2 "SELECT workloadname FROM syscat.workloads WHERE workloadname LIKE '%WL%'" | grep _WL | xargs -I % bash -c 'db2 connect to tpcds; db2 "ALTER WORKLOAD % DISABLE"; db2 DROP WORKLOAD %';

# Other
db2 "CREATE THRESHOLD MAXDBACTIVITYTIME FOR DATABASE ACTIVITIES ENFORCEMENT DATABASE WHEN ACTIVITYTOTALTIME > 300 SECONDS STOP EXECUTION"
db2 "DROP THRESHOLD MAXDBACTIVITYTIME"
DB2_SYSTEM_RAM=3GB
DB2_SYSTEM_RAM=

