# Setting up Apache Spark 

# 1. On Master + Slaves:
* `sudo vim /etc/hosts`
```
<MASTER-IP> master
<SLAVE01-IP> slave01
<SLAVE02-IP> slave02
```
# 2. On Master:
* `ssh-copy-id -i ~/.ssh/id_rsa.pub slave01`
* `ssh-copy-id -i ~/.ssh/id_rsa.pub slave02`
* `ssh slave01`
* `ssh slave02`

# 3. On Master + Slaves:
* `vim ~/.bashrc` 
* Append: `export APACHE="$HOME/apache"`
* `source ~/.bashrc`
* `mkdir $APACHE`
* `cp ./apache-install/spark-2.4.0-bin-hadoop2.7.tgz $APACHE`
* `tar xvfz $APACHE/spark-2.4.0-bin-hadoop2.7.tgz`

# 4. On Master
* Update the path: `vim <DISTGALO-PATH>/makefile` -> Update the `SPARK_INSTALL` variable at the top

# 5. On Master + Slaves
`vim ~/.bashrc`
Append `export SPARK_HOME="$APACHE/spark-2.4.0-bin-hadoop2.7"`
`source ~/.bashrc`

# 6. On Master
* `cd <install-dir-of-choice>/conf`
* `cp slaves.template slaves`
* `vim slaves`
Add entries:
```
master
slave01
slave02
```

# 7. On Master
* `cd <install-dir-of-choice>/conf`
* `cp spark-env.sh.template spark-env.sh`
* `vim spark-env.sh`
* Add: `export SPARK_MASTER_HOST='<MASTER-IP>'`
