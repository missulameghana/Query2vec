# How to install TPCDS on DB2 Instance
1. [Download TPCDS Archive](https://drive.google.com/a/uoit.net/file/d/1Sl9gquagnL_LF8pFtqWy7uXzYnFxl5Uk/view?usp=sharing)
2. `tar xvfz TPCDS.tar.gz -C ~/res/`
3. `db2start`
4. `cd ~/res/TPCDS/ddl/; bash ./setupModi.ksh`
5. `db2 connect to tpcds`
<!-- 6. `cd ~/sqllib/misc; db2 -tf EXPLAIN.DDL` -->

# Verify installation
1. `db2 connect to TPCDS`
2. `db2 list tables for schema TPCDS` (Expect 24 tables)
3. `db2 "select count(*) from TPCDS.CATALOG_PAGE"` (Expect 11718)



