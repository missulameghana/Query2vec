# Setting up Apache Hadoop Distributed File System (HDFS)
## * Step 1 & 2 may have already been completed in the [Setup Spark](./documentation/spark-setup.md)

# 1. On Master + Slaves:
* `sudo vim /etc/hosts`
```
<MASTER-IP> master
<SLAVE01-IP> slave01
<SLAVE02-IP> slave02
```

# 2. On Master:
* `ssh-copy-id -i ~/.ssh/id_rsa.pub slave01`
* `ssh-copy-id -i ~/.ssh/id_rsa.pub slave02`
* `ssh slave01`
* `ssh slave02`

------------------------------

# 3. On Master + Slaves:
* `cp ./apache-install/hadoop-2.7.7.tar.gz $APACHE`
* `tar xvfz $APACHE/hadoop-2.7.7.tar.gz`
* `wget https://www-us.apache.org/dist/spark/spark-2.3.1/spark-2.3.1-bin-hadoop2.7.tgz`
* `tar xvfz ./hadoop-2.7.7.tar.gz`
* Update the path: `vim <DISTGALO-PATH>/makefile` -> Update the `HADOOP_INSTALL` variable at the top

# 4. On Master + Slaves
* `vim ~/.bashrc`
* Append `export HADOOP_HOME="$HOME/apache/hadoop-2.7.7"`
* Append `export LD_LIBRARY_PATH=$HADOOP_HOME/lib/native:$LD_LIBRARY_PATH`
* Append `export PATH=$PATH:$HADOOP_HOME/bin`
* `source ~/.bashrc`

# 5. On All
* `mkdir -p $HOME/hadoop-data/nameNode`
* `mkdir -p $HOME/hadoop-data/dataNode`

# 6. On Master
* `vim $HADOOP_HOME/hadoop-2.7.7/etc/hadoop/core-site.xml`
```
<configuration>
    <property>
        <name>fs.defaultFS</name>
        <value>hdfs://master:9000</value>
    </property>
</configuration>
```
* `vim $HADOOP_HOME/etc/hadoop/hdfs-site.xml`
```
<configuration>
  <property>
    <name>dfs.namenode.name.dir</name>
    <value>/home/alex/hadoop-data/nameNode</value>
  </property>
  <property>
    <name>dfs.datanode.data.dir</name>
    <value>/home/alex/hadoop-data/dataNode</value>
  </property>
  
  <property>
    <name>dfs.replication</name>
    <value>1</value>
  </property>
</configuration>
```

# 8. On Master
* `vim $HADOOP_HOME/etc/hadoop/slaves`
* Append:
* `master`
* `slave1`
* `slave2`


# 9. On Master
* `$HADOOP_HOME/bin/hdfs namenode -format`
* Ensure it is functional: `make hadoop-start` from `<DISTGALO-PATH>`

# 10. On Master 
* `$HADOOP_HOME/bin/hdfs dfs -mkdir -p /user/distGalo/out`
* `$HADOOP_HOME/bin/hdfs dfs -ls /user/distGalo/`


