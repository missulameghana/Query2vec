# Setting up Apache Fuseki

# 1. On Master:
1. Ensure that `$APACHE` is set up (done in [Setup Spark](./documentation/spark-setup.md))
2. `cp ./apache-install/fuseki.zip $APACHE` 
3. `cp ./apache-install/jena-fuseki.zip $APACHE`
4. `unzip $APACHE/fuseki.zip`
5. `unzip $APACHE/jena-fuseki.zip`
6. Create where you'd like the fuseki server to store its data
   > `mkdir ~/fuseki-data`
7. `vim ~/.bashrc` and add:
   > `export FUSEKI_BASE=$APACHE/fuseki`
   > `export FUSEKI_HOME=$APACHE/jena-fuseki/apache-jena-fuseki-3.4.0/`
8. Update the config: `vim $APACHE/fuseki/config.ttl` and ensure `tbd:location "/home/alex/fuseki-data";` is correct
9. `$APACHE/jena-fuseki/apache-jena-fuseki-3.4.0/fuseki-server --update --loc=/home/alex/fuseki-data/ /ds`
