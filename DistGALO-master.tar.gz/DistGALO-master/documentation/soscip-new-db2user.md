# How to create a new user with a DB2 instance
1. log in as root
2. 
```
useradd <new-user>
passwd <new-user>
useradd db2fenc1
passwd db2fenc1
```
3. `/opt/ibm/db2/V11.1/instance/db2icrt -u db2fenc1 <new-user>`
4. `su - <new-user>`
5. `db2start`
6. `db2 create database sample`
