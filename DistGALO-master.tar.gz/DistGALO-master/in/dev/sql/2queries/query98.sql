-- query98
select i_item_desc ,i_category ,i_class ,i_current_price
from store_sales ,item ,date_dim 
where   ss_item_sk = i_item_sk and 
        i_category = 'Sports' and 
        ss_sold_date_sk = d_date_sk and 
        d_year = 2001 and
        d_moy = 12
;
