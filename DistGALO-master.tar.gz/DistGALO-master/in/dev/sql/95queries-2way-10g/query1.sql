-- query 1
with customer_total_return as 
       (select sr_customer_sk as ctr_customer_sk ,sr_store_sk as ctr_store_sk 
       from store_returns ,date_dim 
       where    sr_returned_date_sk = d_date_sk and 
                d_year =1998 
       ) 
select c_customer_id 
from customer_total_return ctr1 ,store ,customer 
where   s_store_sk = ctr1.ctr_store_sk and 
        s_state = 'TN' and 
        ctr1.ctr_customer_sk = c_customer_sk 
;
