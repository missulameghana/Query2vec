-- query78
with ws as 
       (select d_year AS ws_sold_year, ws_item_sk, ws_bill_customer_sk ws_customer_sk 
       from web_sales left join web_returns on  
           wr_order_number=ws_order_number and ws_item_sk=wr_item_sk join 
               date_dim on ws_sold_date_sk = d_date_sk
       where
        wr_order_number is null), 
     cs as 
       (select d_year AS cs_sold_year, cs_item_sk, cs_bill_customer_sk cs_customer_sk
       from catalog_sales left join catalog_returns on  
           cr_order_number=cs_order_number and cs_item_sk=cr_item_sk join 
               date_dim on cs_sold_date_sk = d_date_sk 
        where
        cr_order_number is null ), 
     ss as 
       (select d_year AS ss_sold_year, ss_item_sk, ss_customer_sk        
       from store_sales left join store_returns on  
           sr_ticket_number=ss_ticket_number and ss_item_sk=sr_item_sk join 
               date_dim on ss_sold_date_sk = d_date_sk 
        where
        sr_ticket_number is null ) 
select ss_sold_year, ss_item_sk, ss_customer_sk 
from ss, ws, cs
where
        ws_sold_year=ss_sold_year and
        ws_item_sk=ss_item_sk and
        ws_customer_sk=ss_customer_sk and
        cs_sold_year=ss_sold_year and
        cs_item_sk=cs_item_sk and 
        cs_customer_sk=ss_customer_sk and
        ss_sold_year=1998 
;
