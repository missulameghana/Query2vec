-- query21
select w_warehouse_name ,i_item_id  
from inventory ,warehouse ,item ,date_dim 
where i_current_price < 1.49 and
      i_item_sk = inv_item_sk and 
      inv_warehouse_sk = w_warehouse_sk and
      inv_date_sk = d_date_sk and
      d_year = 1998 and
      d_moy = 4 
;
