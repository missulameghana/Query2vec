-- query49
select ws.ws_item_sk as item ,
        (cast(wr.wr_return_quantity as dec(15,4))/ cast(ws.ws_quantity as dec(15,4))) as return_ratio ,
        (cast(wr.wr_return_amt as dec(15,4))/ cast(ws.ws_net_paid as dec(15,4))) as currency_ratio 
from    web_sales ws left outer join web_returns wr on 
            (ws.ws_order_number = wr.wr_order_number and 
             ws.ws_item_sk = wr.wr_item_sk) ,
        date_dim 
where   wr.wr_return_amt > 10000 and 
        ws.ws_net_profit > 1 and 
        ws.ws_net_paid > 0 and 
        ws.ws_quantity > 0 and 
        ws_sold_date_sk = d_date_sk and 
        d_year = 2000 and 
        d_moy = 12 
;
