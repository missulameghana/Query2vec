-- query55
select i_brand_id brand_id, i_brand brand, ss_ext_sales_price
from date_dim, store_sales, item 
where   d_date_sk = ss_sold_date_sk and 
        ss_item_sk = i_item_sk and 
        i_manager_id=36 and 
        d_moy=12 and 
        d_year=2001 
;
