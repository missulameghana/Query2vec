-- query41
select distinct(i_product_name) 
from item 
where   i_manufact_id > 742 and 
        i_category = 'Women' and 
        i_color = 'orchid' and 
        i_units = 'Pound' and 
        i_size = 'petite' 
;
