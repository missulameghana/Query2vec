-- query97
select ss_customer_sk customer_sk ,ss_item_sk item_sk,
       cs_bill_customer_sk ,cs_item_sk 
from store_sales,date_dim, catalog_sales
where 	ss_sold_date_sk = d_date_sk and
       	cs_sold_date_sk = d_date_sk and
       	d_year=1998 
;
