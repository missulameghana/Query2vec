-- query76
select channel, col_name, d_year, d_qoy, i_category, 
           i_category, ss_ext_sales_price ext_sales_price 
FROM store_sales, item, date_dim
WHERE ss_addr_sk IS NULL AND
      ss_sold_date_sk=d_date_sk AND 
      ss_item_sk=i_item_sk AND
;
