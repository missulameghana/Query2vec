-- query51
WITH web_v1 as 
       (select ws_item_sk item_sk, date_dim.d_date, ws_sales_price as cume_sales 
       from web_sales ,date_dim 
       where ws_sold_date_sk=d_date_sk and d_year=1998 and ws_item_sk is not 
       NULL 
       ), 
     store_v1 as 
       (select ss_item_sk item_sk, date_dim.d_date, ss_sales_price as cume_sales 
       from store_sales ,date_dim 
       where ss_sold_date_sk=d_date_sk and d_year=1998 and ss_item_sk is not 
       NULL 
       ) 
select * 
   from 
      (select date_dim.d_date ,web.cume_sales web_sales ,
              store.cume_sales store_sales 
      from web_v1 web full outer join store_v1 store on (web.item_sk = 
              store.item_sk and web.d_date = store.d_date))x 
where web_cumulative > store_cumulative 
;
