call wlm_set_conn_env(null, '<collectactdata>with details, section and values</collectactdata><collectsectionactuals>base</collectsectionactuals><collectactpartition>ALL</collectactpartition>');
set current schema TPCDS;
.opt set lockplan on optimatch.profile;
-- query14
select * 
from 
   (select 'store' channel, i_brand_id,i_class_id,i_category_id
   from store_sales ,item ,date_dim, web_sales 
   where   ws_item_sk = i_item_sk and
           ss_item_sk = i_item_sk and
           ss_sold_date_sk = d_date_sk and
           d_week_seq = 
      (select d_week_seq 
      from date_dim 
      where d_year = 1998 + 1 and
            d_moy = 12 and
            d_dom = 16)) this_year 
;
.opt set lockplan off;
call wlm_set_conn_env(null, '<collectactdata>NONE</collectactdata><collectsectionactuals>NONE</collectsectionactuals><collectactpartition>ALL</collectactpartition>');
