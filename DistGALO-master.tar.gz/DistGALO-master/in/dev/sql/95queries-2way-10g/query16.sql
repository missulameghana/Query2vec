-- query16
select  cs_order_number
from catalog_sales cs1 ,date_dim ,customer_address ,call_center
where
        d_year = 2001 and
        d_moy > 4 and
        cs1.cs_ship_date_sk = d_date_sk and
        cs1.cs_ship_addr_sk = ca_address_sk and
        cs1.cs_call_center_sk = cc_call_center_sk and       
        ca_state = 'TX' and
        cc_county = 'Williamson County'
;
