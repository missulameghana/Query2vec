-- query08
select s_store_name
from store_sales ,date_dim ,store, 
   (select ca_zip 
   from (
      SELECT substr(ca_zip,1,5) ca_zip 
      FROM customer_address, customer
      WHERE substr(ca_zip,1,1) = '3' and 
      ca_address_sk = c_current_addr_sk and
      c_preferred_cust_flag='Y'
      )A2) V1 
where ss_store_sk = s_store_sk and
      ss_sold_date_sk = d_date_sk and
      d_qoy = 1 and
      d_year = 2002 and
      (substr(s_zip,1,2) = substr(V1.ca_zip,1,2))
;
