-- query02
with wscs as 
       (select sold_date_sk ,sales_price 
       from 
          (select ws_sold_date_sk sold_date_sk ,ws_ext_sales_price sales_price 
          from web_sales) x 
       union all 
       (select cs_sold_date_sk sold_date_sk ,cs_ext_sales_price sales_price 
       from catalog_sales)), 
     wswscs as 
       (select d_week_seq
       from wscs ,date_dim 
       where d_date_sk = sold_date_sk ) 
select distinct * 
from 
   (select wswscs.d_week_seq d_week_seq1
   from wswscs,date_dim 
   where date_dim.d_week_seq = wswscs.d_week_seq and d_year = 2001) y, 
   (select wswscs.d_week_seq d_week_seq2
   from wswscs ,date_dim 
   where date_dim.d_week_seq = wswscs.d_week_seq and d_year = 2001+1) z 
where d_week_seq1=d_week_seq2-53 
;
