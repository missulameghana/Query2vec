-- query54
select distinct c_first_name, c_last_name , c_current_addr_sk 
from 
     (select ws_sold_date_sk sold_date_sk, ws_bill_customer_sk customer_sk, ws_item_sk item_sk from web_sales) ws_sales, 
     item, date_dim, customer 
       where    sold_date_sk = d_date_sk and 
                item_sk = i_item_sk and 
                i_category = 'Jewelry' and 
                i_class = 'consignment' and 
                c_customer_sk = ws_sales.customer_sk and 
                d_moy = 3 and 
                d_year = 1999  
;
