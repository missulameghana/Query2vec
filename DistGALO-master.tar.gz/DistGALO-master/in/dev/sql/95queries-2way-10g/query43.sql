-- query43
select s_store_name, s_store_id, ss_sales_price 
from date_dim, store_sales, store 
where   d_date_sk = ss_sold_date_sk and 
        s_store_sk = ss_store_sk and 
        s_gmt_offset = -5 and 
        d_year = 1998 
;
