-- query71
select i_brand_id brand_id, i_brand brand,t_hour,t_minute
from item, 
   (select ws_ext_sales_price as ext_price, ws_sold_date_sk as sold_date_sk, 
           ws_item_sk as sold_item_sk, ws_sold_time_sk as time_sk 
   from web_sales,date_dim 
   where d_date_sk = ws_sold_date_sk and d_moy=12 and d_year=2001 ) as tmp,
        time_dim 
where sold_item_sk = i_item_sk and
      i_manager_id=1 and
      time_sk = t_time_sk and 
      t_meal_time = 'breakfast'
;
