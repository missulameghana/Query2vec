-- query17
select i_item_id ,i_item_desc ,s_state
from store_sales ,store_returns ,date_dim d1 ,date_dim d2 ,store ,item 
where d1.d_quarter_name = '2000Q1' and
      d1.d_date_sk = ss_sold_date_sk and 
      i_item_sk = ss_item_sk and
      s_store_sk = ss_store_sk and 
      ss_customer_sk = sr_customer_sk and
      ss_item_sk = sr_item_sk and 
      ss_ticket_number = sr_ticket_number and
      sr_returned_date_sk = d2.d_date_sk and
      d2.d_quarter_name = '2000Q1' 
;
