-- query74

select c_customer_id customer_id ,c_first_name customer_first_name ,
       c_last_name customer_last_name ,'s' sale_type
from customer ,store_sales ,date_dim, store_returns 
where 
        c_customer_sk = ss_customer_sk and
        ss_sold_date_sk = d_date_sk and
        d_year = 2001 and
        c_customer_sk = sr_customer_sk and
        ss_store_sk = sr_store_sk and
        ss_item_sk = sr_item_sk 
;
