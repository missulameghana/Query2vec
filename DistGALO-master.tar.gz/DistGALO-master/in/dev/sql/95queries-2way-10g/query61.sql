-- query61
select p_promo_name, i_item_id, ss_ext_sales_price promotions
from store_sales ,store ,promotion ,date_dim ,customer ,customer_address , item 
where    ss_sold_date_sk = d_date_sk and
         ss_store_sk = s_store_sk and 
         ss_promo_sk = p_promo_sk and
         ss_customer_sk= c_customer_sk and 
         ca_address_sk = c_current_addr_sk and
         ss_item_sk = i_item_sk and 
         ca_gmt_offset = s_gmt_offset and
         i_category = 'Electronics' and 
         p_channel_dmail = 'Y' and
         d_year = 1999 and
         d_moy = 11 
;
