-- query40
select w_state ,i_item_id 
from  catalog_sales, catalog_returns, warehouse ,item , date_dim 
where i_item_sk = cs_item_sk and
      cs_order_number =  cr_order_number and
      cs_item_sk = cr_item_sk and
      cs_warehouse_sk = w_warehouse_sk and
      cs_sold_date_sk = d_date_sk and
      i_current_price = 1.49 and
      d_year = 1998 and
      d_moy = 4
;
