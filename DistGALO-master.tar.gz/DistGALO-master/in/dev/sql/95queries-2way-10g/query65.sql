-- query65

select s_store_name, i_item_id, sum(ss_sales_price) as revenue
from store, item, store_sales, date_dim 
where
        ss_sold_date_sk = d_date_sk and
        d_year = 1998 AND
        s_store_sk = ss_store_sk and
        i_item_sk = ss_item_sk
group by s_store_name, i_item_id
;
