-- query37
select i_item_id ,i_item_desc ,i_current_price 
from item, inventory, date_dim, catalog_sales 
where i_current_price = 9.59 and
        inv_item_sk = i_item_sk and
        cs_item_sk = i_item_sk and
        d_date_sk = inv_date_sk and
        d_year = 2001 and
        d_moy = 6 and
        i_manufact_id = 505 and
        inv_quantity_on_hand = 754 
;
