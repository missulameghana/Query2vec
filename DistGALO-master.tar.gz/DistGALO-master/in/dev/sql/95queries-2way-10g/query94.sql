-- query94
select ws_order_number 
from web_sales ws1 ,date_dim ,customer_address ,web_site 
where 
      d_year = 1999 and
      d_moy > 5 and
      ws1.ws_ship_date_sk = d_date_sk and
      ws1.ws_ship_addr_sk = ca_address_sk and
      ca_state = 'TX' and
      ws1.ws_web_site_sk =  web_site_sk and
      web_company_name = 'pri'  
;
