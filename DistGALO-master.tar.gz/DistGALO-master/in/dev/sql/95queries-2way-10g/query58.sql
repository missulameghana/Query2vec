-- query58
select i_item_id item_id ,ws_ext_sales_price ws_item_rev 
from    web_sales ,item ,date_dim 
where   ws_item_sk = i_item_sk and 
        d_date in 
            (select d_date 
             from date_dim 
             where d_week_seq =(select d_week_seq 
                                from date_dim 
                                where d_date = '1998-02-19')) and 
        ws_sold_date_sk = d_date_sk 
;
