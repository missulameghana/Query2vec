-- query09
select *
from reason, store_sales
where r_reason_sk = 1 and
      ss_quantity < 100
;
