-- query66
select w_warehouse_name ,w_warehouse_sq_ft ,w_city ,w_county ,w_state ,
           w_country ,'DIAMOND' || ',' || 'AIRBORNE' as ship_carriers ,d_year as year
   from web_sales ,warehouse ,date_dim ,time_dim ,ship_mode 
   where ws_warehouse_sk = w_warehouse_sk and
         ws_sold_date_sk = d_date_sk and 
         ws_sold_time_sk = t_time_sk and
         ws_ship_mode_sk = sm_ship_mode_sk 
         and d_year = 2002 and
         t_time > 49530 and
         sm_carrier = 'DIAMOND'
;
