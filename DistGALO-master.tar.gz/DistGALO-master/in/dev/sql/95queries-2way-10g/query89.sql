-- query89
select i_category, i_class, i_brand, s_store_name, s_company_name, d_moy, 
           ss_sales_price 
from item, store_sales, date_dim, store 
where   ss_item_sk = i_item_sk and 
        ss_sold_date_sk = d_date_sk and 
        ss_store_sk = s_store_sk and 
        d_year = 2000 and 
        i_category = 'Home' and 
        i_class in 'wallpaper'
;
