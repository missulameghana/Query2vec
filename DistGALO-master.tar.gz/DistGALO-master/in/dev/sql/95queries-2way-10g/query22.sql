-- query22
select i_product_name ,i_brand ,i_class ,i_category
from inventory ,date_dim ,item ,warehouse 
where inv_date_sk=d_date_sk and
      inv_item_sk=i_item_sk and
      inv_warehouse_sk = w_warehouse_sk and
      d_year=1998 
;
