-- query46
select c_last_name ,c_first_name ,bought_addr.ca_city ,ss_ticket_number 
from store_sales, store, customer, customer_address bought_addr, date_dim
where
	store_sales.ss_sold_date_sk = date_dim.d_date_sk and 
       	store_sales.ss_addr_sk = bought_addr.ca_address_sk and 
        store_sales.ss_store_sk = store.s_store_sk and 
        date_dim.d_year = 1998 and
	date_dim.d_dow = 6 and
	store.s_city = 'Fairview' and
	customer.c_current_addr_sk = bought_addr.ca_address_sk
;

