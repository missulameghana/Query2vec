-- query86
select i_category ,i_class
from web_sales ,date_dim d1 ,item 
where   d1.d_year = 1998 and 
        d1.d_date_sk = ws_sold_date_sk and 
        i_item_sk = ws_item_sk 
;
