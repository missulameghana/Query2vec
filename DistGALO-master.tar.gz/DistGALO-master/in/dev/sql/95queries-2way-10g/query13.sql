-- query13
select avg(ss_quantity) ,avg(ss_ext_sales_price) ,avg(ss_ext_wholesale_cost) ,
        sum(ss_ext_wholesale_cost) 
from store_sales ,store ,customer_demographics ,household_demographics ,
        customer_address ,date_dim 
where s_store_sk = ss_store_sk and
ss_sold_date_sk = d_date_sk and
d_year = 2001 and
        ss_hdemo_sk=hd_demo_sk and
        cd_demo_sk = ss_cdemo_sk and 
        cd_marital_status = 'M' and
        cd_education_status = '2 yr Degree' and 
        ss_sales_price > 150.00 and
        hd_dep_count = 3 and
        ss_addr_sk = ca_address_sk and
        ca_country = 'United States' and 
        ca_state = 'TX' and
        ss_net_profit > 100
;
