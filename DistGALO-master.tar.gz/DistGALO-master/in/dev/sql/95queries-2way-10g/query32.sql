-- query32
select cs_ext_discount_amt 
from catalog_sales ,item ,date_dim 
where   i_manufact_id = 269 and 
        i_item_sk = cs_item_sk and 
        d_year = 1998 and
        d_qoy = 2 and 
        d_date_sk = cs_sold_date_sk  
;
