-- query59
select  ss1.ss_item_sk as item_id, 
                (ss2.ss_sales_price/(ss1.ss_sales_price+0.1)) as percentage_increase
from date_dim dd1, date_dim dd2, store_sales ss1, store_sales ss2
where
    dd1.d_year = 2001 and
    dd1.d_day_name = 'Sunday' and
    dd1.d_qoy = 4 and
    ss1.ss_store_sk = ss2.ss_store_sk and 
    ss1.ss_item_sk = ss2.ss_item_sk and
    ss1.ss_customer_sk = ss2.ss_customer_sk and
    dd2.d_year = 2001+1 and
    dd2.d_day_name = 'Sunday' and
    dd2.d_qoy = 4 and
    ss2.ss_sales_price > ss1.ss_sales_price
;
