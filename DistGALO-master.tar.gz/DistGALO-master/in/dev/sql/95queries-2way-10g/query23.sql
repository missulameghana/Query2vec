-- query23
select substr(i_item_desc,1,30) itemdesc,i_item_sk item_sk,d_date solddate
from store_sales ,date_dim ,item, catalog_sales
where ss_sold_date_sk = d_date_sk and
      ss_item_sk = i_item_sk and
      cs_bill_customer_sk = ss_customer_sk and
      cs_item_sk = i_item_sk and
      d_year = 1999 and
      d_moy = 1
;
