-- query56
with cs as 
       (select i_item_id, cs_ext_sales_price total_sales 
       from catalog_sales, date_dim, customer_address, item 
       where i_item_id in 
          (select i_item_id 
          from item 
          where i_color = 'orchid') and 
		cs_item_sk = i_item_sk and 
		cs_sold_date_sk = d_date_sk and 
		d_year = 2000 and 
		d_moy = 1 and 
		cs_bill_addr_sk = ca_address_sk and 
		ca_gmt_offset = -8 
       ) 
select i_item_id ,total_sales
from cs 
;
