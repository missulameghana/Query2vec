-- query05
with ssr as 
       (select s_store_id, sales_price as sales, profit, return_amt as returns, net_loss as profit_loss
       from 
          (select ss_store_sk as store_sk,
          ss_sold_date_sk as date_sk, 
          ss_ext_sales_price as sales_price,
          ss_net_profit as profit,
          cast(0 as decimal(7,2)) as return_amt,
          cast(0 as decimal(7,2)) as net_loss
          from store_sales) salesreturns, date_dim, store
            where date_sk = d_date_sk and d_year = 1998 and d_moy = 8 and store_sk = s_store_sk
        )  
select 'store channel' as channel ,
       'store' || s_store_id as id , 
        sales ,
        returns ,
        (profit - profit_loss) as profit 
from ssr
;
