-- query64

with cs_ui as 
       (select cs_item_sk, cs_sold_date_sk
       from catalog_sales ,catalog_returns 
       where cs_item_sk = cr_item_sk and
       cs_order_number = cr_order_number)
select i_item_id, i_item_desc
from item, cs_ui, date_dim
where 
       i_item_sk = cs_ui.cs_item_sk and
       d_date_sk = cs_ui.cs_sold_date_sk and
       i_color = 'maroon' and
       i_current_price < 35 + 10 and
       d_year = 2000
;
