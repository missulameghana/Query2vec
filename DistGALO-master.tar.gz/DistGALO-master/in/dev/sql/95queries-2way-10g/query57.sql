-- query57
select i_category, i_brand, cc_name, d_year, d_moy, 
cs_sales_price 
from    item, catalog_sales, date_dim, call_center 
where   cs_item_sk = i_item_sk and
        cs_sold_date_sk = d_date_sk and
        cc_call_center_sk= cs_call_center_sk and
        d_year = 2000 
;

