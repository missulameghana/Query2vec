-- query79
select c_last_name,c_first_name,s_city,ss_ticket_number, 
       ss_ticket_number ,ss_customer_sk ,store.s_city
from store_sales,date_dim,store,household_demographics, customer
where store_sales.ss_sold_date_sk = date_dim.d_date_sk and 
      store_sales.ss_store_sk = store.s_store_sk and 
      store_sales.ss_hdemo_sk = household_demographics.hd_demo_sk and
      ss_customer_sk = c_customer_sk and
      household_demographics.hd_dep_count = 8 and
      date_dim.d_dow = 1 and
      date_dim.d_year = 1998+3 and 
      store.s_number_employees > 100 
;
