-- query62
select w_warehouse_name,1,20 ,sm_type ,web_name
from web_sales ,warehouse ,ship_mode ,web_site ,date_dim 
where ws_ship_date_sk = d_date_sk and
      ws_warehouse_sk =  w_warehouse_sk and
      ws_ship_mode_sk = sm_ship_mode_sk and 
      ws_web_site_sk = web_site_sk and
      d_year = 1998 
;
