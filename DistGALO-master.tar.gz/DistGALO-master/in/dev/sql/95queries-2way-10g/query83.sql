-- query83
with sr_items as 
       (select i_item_id item_id, sr_return_quantity sr_item_qty
       from store_returns, item, date_dim 
       where sr_item_sk = i_item_sk and
       d_year IN (1998,1999) and
       d_moy < 12 and
       sr_returned_date_sk = d_date_sk), 
     cr_items as 
       (select i_item_id item_id, cr_return_quantity cr_item_qty 
       from catalog_returns, item, date_dim 
       where cr_item_sk = i_item_sk and
       d_year IN (1998,1999) and
       d_moy < 11 and
       cr_returned_date_sk = d_date_sk), 
     wr_items as 
       (select i_item_id item_id, wr_return_quantity wr_item_qty
       from web_returns, item, date_dim 
       where wr_item_sk = i_item_sk and
       d_year IN (1998,1999) and
       d_moy < 11 and
       wr_returned_date_sk = d_date_sk) 
select sr_items.item_id ,sr_item_qty ,
        cr_item_qty ,
        wr_item_qty
from sr_items ,cr_items ,wr_items 
where sr_items.item_id=cr_items.item_id and sr_items.item_id=wr_items.item_id 
;
