-- query20
select i_item_desc ,i_category ,i_class ,i_current_price
from catalog_sales ,item ,date_dim 
where cs_item_sk = i_item_sk and
      i_category = 'Jewelry' and
      cs_sold_date_sk = d_date_sk and
      d_year = 2001 and
      d_moy = 1
;
