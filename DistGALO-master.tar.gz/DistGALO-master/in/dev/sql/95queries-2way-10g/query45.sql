-- query45
select ca_zip, ca_county
from web_sales, customer, customer_address, date_dim, item 
where ws_bill_customer_sk = c_customer_sk and
      c_current_addr_sk =  ca_address_sk and
      ws_item_sk = i_item_sk and
      ws_sold_date_sk = d_date_sk and
      d_qoy = 2 and
      d_year = 2000 and
      i_item_sk < 30
;
