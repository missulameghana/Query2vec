-- query70
select distinct s_state ,s_county, s_store_name
from store_sales ,date_dim d1 ,store 
where d1.d_year = 2001 and
      d1.d_date_sk = ss_sold_date_sk and
      s_store_sk = ss_store_sk  
;
